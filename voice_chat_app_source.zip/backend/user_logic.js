const { get, run, query } = require('./db');

/**
 * Update user's VIP status (mock implementation using simplified logic for SQLite)
 * @param {number} userId
 */
async function updateVipStatus(userId) {
    // Simplified logic: VIP is set to true for demonstration purposes
    await run('UPDATE users SET is_vip = ? WHERE id = ?', [1, userId]);
    console.log(`User ${userId} granted VIP status (Mock).`);
}

/**
 * Get user profile
 * @param {number} userId
 */
async function getUserProfile(userId) {
    const user = await get('SELECT id, username, coins, is_vip FROM users WHERE id = ?', [userId]);
    return user;
}

/**
 * Send a gift from one user to another
 * @param {number} senderId
 * @param {number} receiverId
 * @param {number} giftId
 */
async function sendGift(senderId, receiverId, giftId) {
    const gift = await get('SELECT cost FROM gifts WHERE id = ?', [giftId]);
    if (!gift) {
        throw new Error('Gift not found');
    }
    const cost = gift.cost;

    // 1. Check sender's balance
    const sender = await get('SELECT coins FROM users WHERE id = ?', [senderId]);
    if (!sender) {
        throw new Error('Sender not found');
    }
    if (sender.coins < cost) {
        throw new Error('Insufficient coins');
    }

    // 2. Deduct from sender and add to recipient (simplified transaction)
    await run('UPDATE users SET coins = coins - ? WHERE id = ?', [cost, senderId]);
    await run('UPDATE users SET coins = coins + ? WHERE id = ?', [cost, receiverId]);

    return { success: true, newBalance: sender.coins - cost };
}

module.exports = {
    updateVipStatus,
    getUserProfile,
    sendGift,
    // Add other user-related logic here (e.g., buying coins)
};
