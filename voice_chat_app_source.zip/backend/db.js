// db.js - SQLite3 implementation
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = path.join(__dirname, 'voice_chat.db');
const db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) {
        console.error('Error connecting to SQLite database:', err.message);
    } else {
        console.log('Connected to the SQLite database.');

        // Function to run a single statement
        const runStatement = (sql, params = []) => {
            return new Promise((resolve, reject) => {
                db.run(sql, params, function(err) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve({ id: this.lastID, changes: this.changes });
                    }
                });
            });
        };

        // Initialize tables
        (async () => {
            try {
                await runStatement('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, coins INTEGER DEFAULT 5000, is_vip BOOLEAN DEFAULT 0, fcm_token TEXT)');
                await runStatement('CREATE TABLE IF NOT EXISTS rooms (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, host_id INTEGER, is_active BOOLEAN DEFAULT 0)');
                await runStatement('CREATE TABLE IF NOT EXISTS gifts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, cost INTEGER NOT NULL)');

                // Insert initial gifts (SQLite way for ON CONFLICT IGNORE)
                await runStatement("INSERT OR IGNORE INTO gifts (id, name, cost) VALUES (1, 'وردة', 10)");
                await runStatement("INSERT OR IGNORE INTO gifts (id, name, cost) VALUES (2, 'قلب', 50)");
                await runStatement("INSERT OR IGNORE INTO gifts (id, name, cost) VALUES (3, 'سيارة', 500)");

                console.log("SQLite tables initialized successfully.");
            } catch (error) {
                console.error("Error initializing SQLite tables:", error);
            }
        })();
    }
});

const query = (sql, params = []) => {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        });
    });
};

const get = (sql, params = []) => {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) {
                reject(err);
            } else {
                resolve(row);
            }
        });
    });
};

const run = (sql, params = []) => {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) {
                reject(err);
            } else {
                resolve({ id: this.lastID, changes: this.changes });
            }
        });
    });
};

module.exports = {
    query,
    get,
    run,
    db // Export for direct access if needed
};
