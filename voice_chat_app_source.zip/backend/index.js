// index.js
const { startServer } = require('./server');
startServer();
