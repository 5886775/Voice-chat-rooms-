const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { query, get, run } = require('./db');
const { updateVipStatus } = require('./user_logic'); // سنقوم بإنشاء هذا الملف لاحقًا

const JWT_SECRET = process.env.JWT_SECRET || 'your_super_secret_key';
const SALT_ROUNDS = 10;

/**
 * Register a new user
 * @param {string} username
 * @param {string} password
 */
async function registerUser(username, password) {
    try {
        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
        
        // Insert into users table
        const result = await run(
            'INSERT INTO users (username, password) VALUES (?, ?)',
            [username, hashedPassword]
        );

        const user = { id: result.id, username, coins: 5000, is_vip: 0 };
        const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
        return { user, token };
    } catch (error) {
        if (error.message.includes('SQLITE_CONSTRAINT: UNIQUE')) {
            throw new Error('Username already exists');
        }
        throw error;
    }
}

/**
 * Login user
 * @param {string} username
 * @param {string} password
 */
async function loginUser(username, password) {
    // Retrieve user by username
    const user = await get(
        'SELECT * FROM users WHERE username = ?',
        [username]
    );

    if (!user) {
        throw new Error('User not found');
    }

    // Compare password
    const match = await bcrypt.compare(password, user.password);

    if (!match) {
        throw new Error('Invalid credentials');
    }

    // Update VIP status on login (for the 4-month rule check - mock for now)
    // await updateVipStatus(user.id);

    const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
    return { user: { id: user.id, username: user.username, coins: user.coins, is_vip: user.is_vip }, token };
}

/**
 * Middleware to protect routes
 */
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

module.exports = {
    registerUser,
    loginUser,
    authenticateToken,
};
