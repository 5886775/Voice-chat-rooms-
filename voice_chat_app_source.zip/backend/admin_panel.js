const express = require('express');
const db = require('./db');

const router = express.Router();

// Middleware to check for admin role (Mock for now)
function isAdmin(req, res, next) {
    // In a real application, this would check a JWT claim or database field
    // For now, we'll assume a hardcoded admin key or simple check
    if (req.headers['x-admin-key'] === 'ADMIN_SECRET_KEY') {
        next();
    } else {
        res.status(403).json({ error: 'Forbidden: Admin access required' });
    }
}

router.use(isAdmin);

// --- User Management ---

// Get all users
router.get('/users', async (req, res) => {
    try {
        const result = await db.query(\`
            SELECT id, email, username, coins, is_vip, invited_friends, registration_date, vip_start_date
            FROM users
            ORDER BY id DESC
        \`);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Update user balance
router.post('/users/:id/coins', async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        const { amount } = req.body; // Can be positive or negative

        if (isNaN(userId) || typeof amount !== 'number') {
            return res.status(400).json({ error: 'Invalid user ID or amount' });
        }

        const result = await db.query(\`
            UPDATE users
            SET coins = coins + $1
            WHERE id = $2
            RETURNING id, coins
        \`, [amount, userId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({ message: 'User balance updated successfully', user: result.rows[0] });
    } catch (error) {
        console.error('Error updating user balance:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// --- Gift Management ---

// Get all gifts
router.get('/gifts', async (req, res) => {
    try {
        const result = await db.query(\`SELECT * FROM gifts ORDER BY cost ASC\`);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching gifts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Add new gift
router.post('/gifts', async (req, res) => {
    try {
        const { name, cost, image_url } = req.body;
        if (!name || typeof cost !== 'number' || cost <= 0) {
            return res.status(400).json({ error: 'Invalid gift data' });
        }

        const result = await db.query(\`
            INSERT INTO gifts (name, cost, image_url) VALUES ($1, $2, $3)
            RETURNING *
        \`, [name, cost, image_url]);

        res.status(201).json({ message: 'Gift added successfully', gift: result.rows[0] });
    } catch (error) {
        console.error('Error adding gift:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
