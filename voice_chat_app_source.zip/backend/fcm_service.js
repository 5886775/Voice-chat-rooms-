// This is a mock FCM service file.
// Full implementation requires a Firebase Admin SDK setup and a service account key file.

// const admin = require('firebase-admin');
// const serviceAccount = require('./path/to/your/serviceAccountKey.json');

// admin.initializeApp({
//   credential: admin.credential.cert(serviceAccount),
// });

/**
 * Sends a push notification to a specific user.
 * @param {string} fcmToken The Firebase Cloud Messaging token for the device.
 * @param {string} title The title of the notification.
 * @param {string} body The body of the notification.
 * @param {object} data Custom data payload.
 */
async function sendPushNotification(fcmToken, title, body, data = {}) {
    console.log(\`[FCM Mock] Sending notification to token: \${fcmToken}\`);
    console.log(\`[FCM Mock] Title: \${title}, Body: \${body}\`);
    console.log(\`[FCM Mock] Data: \${JSON.stringify(data)}\`);

    // In a real implementation:
    // const message = {
    //     notification: {
    //         title: title,
    //         body: body,
    //     },
    //     data: data,
    //     token: fcmToken,
    // };
    //
    // try {
    //     const response = await admin.messaging().send(message);
    //     console.log('Successfully sent message:', response);
    //     return response;
    // } catch (error) {
    //     console.error('Error sending message:', error);
    //     throw error;
    // }
}

module.exports = {
    sendPushNotification,
};
