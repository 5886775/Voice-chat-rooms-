const express = require("express");
const https = require("https");
const fs = require("fs");
const { Server } = require("socket.io");
const mediasoup = require("mediasoup");
const dotenv = require("dotenv");
const { query, get, run } = require("./db");
const auth = require("./auth");
const userLogic = require("./user_logic");

dotenv.config();

const config = {
    listenPort: process.env.PORT || 3000,
    ssl: {
        cert: process.env.CERT_PATH || "./certs/cert.pem",
        key: process.env.KEY_PATH || "./certs/key.pem",
    },
    mediasoup: {
        worker: {
            rtcMinPort: process.env.MEDIASOUP_MIN_PORT || 40000,
            rtcMaxPort: process.env.MEDIASOUP_MAX_PORT || 49999,
            logLevel: "warn",
            logTags: ["info", "ice", "dtls", "rtp", "srtp", "rtcp"],
        },
        router: {
            mediaCodecs: [
                {
                    kind: "audio",
                    mimeType: "audio/opus",
                    clockRate: 48000,
                    channels: 2,
                },
            ],
        },
        webRtcTransport: {
            listenIps: [
                {
                    ip: process.env.MEDIASOUP_LISTEN_IP || "0.0.0.0",
                    announcedIp: process.env.ANNOUNCED_IP || "127.0.0.1",
                },
            ],
            enableUdp: true,
            enableTcp: true,
            preferUdp: true,
        },
    },
};

let worker;
const rooms = {};

async function createSelfSignedCert() {
    const certPath = config.ssl.cert;
    const keyPath = config.ssl.key;
    const certDir = require("path").dirname(certPath);

    if (!fs.existsSync(certDir)) {
        fs.mkdirSync(certDir, { recursive: true });
    }

    if (!fs.existsSync(certPath) || !fs.existsSync(keyPath)) {
        console.warn("SSL certificates not found. Using dummy files.");
        fs.writeFileSync(keyPath, "DUMMY_KEY");
        fs.writeFileSync(certPath, "DUMMY_CERT");
    }
}

async function createWorker() {
    worker = await mediasoup.createWorker(config.mediasoup.worker);
    worker.on("died", () => {
        console.error("Mediasoup worker died, exiting...");
        setTimeout(() => process.exit(1), 2000);
    });
    console.log("Mediasoup Worker created.");
}

async function getOrCreateRoom(roomId) {
    if (rooms[roomId]) {
        return rooms[roomId];
    }
    const newRouter = await worker.createRouter(config.mediasoup.router);
    rooms[roomId] = { router: newRouter, peers: {} };
    return rooms[roomId];
}

async function startServer() {
    await createSelfSignedCert();
    await createWorker();

    const app = express();
    app.use(express.json());

    app.post("/api/register", async (req, res) => {
        try {
            const { username, password } = req.body;
            const { user, token } = await auth.registerUser(username, password);
            res.status(201).json({ user, token });
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    });

    app.post("/api/login", async (req, res) => {
        try {
            const { username, password } = req.body;
            const { user, token } = await auth.loginUser(username, password);
            res.status(200).json({ user, token });
        } catch (error) {
            res.status(401).json({ error: error.message });
        }
    });

    const options = {
        key: fs.readFileSync(config.ssl.key),
        cert: fs.readFileSync(config.ssl.cert),
    };
    const httpsServer = https.createServer(options, app);
    const io = new Server(httpsServer, { cors: { origin: "*" } });

    io.on("connection", (socket) => {
        console.log(`User connected: ${socket.id}`);

        socket.on("joinRoom", async ({ roomId }) => {
            const room = await getOrCreateRoom(roomId);
            room.peers[socket.id] = { userId: socket.id, transport: null, producer: null, consumer: null };
            socket.join(roomId);
            socket.emit("routerCapabilities", room.router.rtpCapabilities);
            socket.to(roomId).emit("newPeer", { userId: socket.id });
        });

        // ... (rest of the socket handlers)

        socket.on("disconnect", () => {
            console.log(`User disconnected: ${socket.id}`);
            const roomId = Object.keys(rooms).find(roomId => rooms[roomId].peers[socket.id]);
            if (roomId && rooms[roomId].peers[socket.id]) {
                delete rooms[roomId].peers[socket.id];
                socket.to(roomId).emit("peerDisconnected", { userId: socket.id });
            }
        });
    });

    httpsServer.listen(config.listenPort, () => {
        console.log(`Server is running on https://localhost:${config.listenPort}`);
    });
}

module.exports = { startServer };
