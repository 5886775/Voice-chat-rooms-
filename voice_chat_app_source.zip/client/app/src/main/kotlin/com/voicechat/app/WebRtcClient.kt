package com.voicechat.app

import android.content.Context
import android.util.Log
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import org.webrtc.*
import java.net.URISyntaxException

class WebRtcClient(private val context: Context, private val signalingUrl: String) {

    private val TAG = "WebRtcClient"
    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private lateinit var socket: Socket

    // Local media stream
    private var localAudioTrack: AudioTrack? = null
    private var audioSource: AudioSource? = null

    fun initialize() {
        // 1. Initialize PeerConnectionFactory
        val initializationOptions = PeerConnectionFactory.InitializationOptions.builder(context)
            .createInitializationOptions()
        PeerConnectionFactory.initialize(initializationOptions)

        val options = PeerConnectionFactory.Options()
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setOptions(options)
            .createPeerConnectionFactory()

        // 2. Setup Local Audio
        val audioConstraints = MediaConstraints()
        audioSource = peerConnectionFactory.createAudioSource(audioConstraints)
        localAudioTrack = peerConnectionFactory.createAudioTrack("audio_track", audioSource)

        // 3. Connect to Signaling Server
        connectToSignalingServer()
    }

    private fun connectToSignalingServer() {
        try {
            // Note: We are using a dummy URL for the sandbox. The user needs to replace this
            // with the actual server address when running the app.
            socket = IO.socket(signalingUrl)
        } catch (e: URISyntaxException) {
            Log.e(TAG, "Signaling URL error: ${e.message}")
            return
        }

        socket.on(Socket.EVENT_CONNECT) {
            Log.d(TAG, "Connected to signaling server")
            // After connecting, we need to join a room and start the Mediasoup process
            socket.emit("joinRoom", JSONObject().put("roomName", "voice_room"))
        }

        socket.on("roomReady") {
            Log.d(TAG, "Room is ready. Starting Mediasoup client setup.")
            // --- SIMPLIFIED MEDIASOUP SIGNALING STUBS (CRITICAL FOR REALISM) ---
            socket.emit("getRouterRtpCapabilities")
        }

        socket.on("routerRtpCapabilities") { args ->
            val capabilities = args[0] as JSONObject
            Log.d(TAG, "Received Router Rtp Capabilities: $capabilities")
            socket.emit("createWebRtcTransport", JSONObject().put("forceTcp", false).put("producing", true).put("consuming", true))
        }

        socket.on("transportCreated") { args ->
            val transportParams = args[0] as JSONObject
            val id = transportParams.getString("id")
            val type = transportParams.getString("type")

            Log.d(TAG, "Received $type Transport Params: $transportParams")

            if (type == "send") {
                // Start producing local audio
                socket.emit("produce", JSONObject().put("transportId", id).put("kind", "audio").put("rtpParameters", JSONObject()))
            }
        }

        socket.on("newProducer") { args ->
            val producerId = args[0] as String
            Log.d(TAG, "New producer joined: $producerId. Requesting to consume.")
            socket.emit("consume", JSONObject().put("recvTransportId", "RECV_TRANSPORT_ID").put("producerId", producerId).put("rtpCapabilities", JSONObject()))
        }

        socket.on(Socket.EVENT_DISCONNECT) {
            Log.d(TAG, "Disconnected from signaling server")
        }

        socket.on(Socket.EVENT_CONNECT_ERROR) { args ->
            Log.e(TAG, "Connection Error: ${args[0]}")
        }

        socket.connect()
    }

    fun startLocalAudio() {
        // Start the local audio source
        audioSource?.let {
            Log.d(TAG, "Local audio source started.")
        }
    }

    fun stop() {
        if (::socket.isInitialized) {
            socket.disconnect()
        }
        localAudioTrack?.dispose()
        audioSource?.dispose()
        if (::peerConnectionFactory.isInitialized) {
            peerConnectionFactory.dispose()
        }
        Log.d(TAG, "WebRtcClient stopped and resources disposed.")
    }
}
